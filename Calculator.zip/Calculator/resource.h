﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// Calculator.rc에서 사용되고 있습니다.
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CALCULATOR_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_CLOSE                       1001
#define IDC_NUM1                        1002
#define IDC_NUM4                        1003
#define IDC_NUM7                        1004
#define IDC_NUM2                        1005
#define IDC_NUM5                        1006
#define IDC_NUM8                        1007
#define IDC_NUM3                        1008
#define IDC_NUM6                        1009
#define IDC_NUM9                        1010
#define IDC_DIVISION                    1011
#define IDC_MINUS                       1012
#define IDC_PLUS                        1013
#define IDC_CALC                        1014
#define IDC_MULTI                       1015
#define IDC_EDIT2                       1016
#define IDC_NUM0                        1018
#define IDC_DOT                         1019
#define IDC_BACK                        1020
#define IDC_CLEAR                       1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
